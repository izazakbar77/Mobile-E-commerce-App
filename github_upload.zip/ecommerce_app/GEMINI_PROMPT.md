# 🤖 Android Studio Gemini — Full Project Prompt
## MAD Semester Project: Mobile E-Commerce App in Flutter

---

## PASTE THIS INTO ANDROID STUDIO GEMINI:

---

I am building a complete Mobile E-Commerce Application for my Mobile Application Development (MAD) semester project using Flutter in Android Studio. Below is the full project specification. Help me complete, debug, and enhance this project.

### PROJECT OVERVIEW
- **App Name:** ShopApp
- **Type:** Mobile E-Commerce Application
- **Framework:** Flutter (Dart)
- **Students:** Muhammad Murtaza (23MDBCS443) & Izaz Akbar (23MDBCS436)
- **Semester:** 6th, Section AI

---

### ARCHITECTURE: Client-Server (Provider Pattern)
The app uses Flutter with Provider for state management. No backend is connected yet — all data is mocked locally. The architecture follows MVC-like separation:
- **Models:** User, Product, Cart, Order, Payment
- **Providers (State):** AuthProvider, ProductProvider, CartProvider, OrderProvider
- **Screens:** Login, Register, Home, ProductListing, ProductDetail, Cart, Checkout, OrderSuccess, Orders, Profile

---

### CLASS DIAGRAM (already implemented)

**User:** userID, name, email, password
**Product:** productID, name, price, description, imageUrl, category, rating, stock
**Cart / CartItem:** cartID, userID, items[], quantity, totalPrice
**Order:** orderID, userID, items[], totalAmount, status (enum), shippingAddress, createdAt
**Payment:** paymentID, orderID, method (enum), status (enum), amount

**Relationships:**
- User → Cart (1:1)
- Cart → Product (1:many)
- User → Order (1:many)
- Order → Payment (1:1)

---

### SCREENS FLOW (already built)

1. **LoginScreen** → email/password form → navigates to HomeScreen
2. **RegisterScreen** → name/email/password/confirm → navigates to HomeScreen
3. **HomeScreen** (BottomNavigationBar with 5 tabs):
   - Tab 1: Home (featured products, categories, banner)
   - Tab 2: ProductListingScreen (search + category filter + grid)
   - Tab 3: CartScreen (list items, qty controls, total, checkout button)
   - Tab 4: OrdersScreen (order history with status badges)
   - Tab 5: ProfileScreen (user info, stats, menu items, logout)
4. **ProductDetailScreen** → image, name, rating, price, description, Add to Cart
5. **CheckoutScreen** → address form + payment method → place order
6. **OrderSuccessScreen** → confirmation with order summary

---

### CURRENT pubspec.yaml DEPENDENCIES
```yaml
dependencies:
  flutter:
    sdk: flutter
  provider: ^6.1.1
  shared_preferences: ^2.2.2
  http: ^1.1.0
  cached_network_image: ^3.3.0
  flutter_rating_bar: ^4.0.1
  badges: ^3.1.2
  cupertino_icons: ^1.0.6
```

---

### TASKS I NEED HELP WITH:

**1. Fix any compilation errors** — review my code and fix import issues, missing files, or Dart null-safety errors.

**2. Add Wishlist feature:**
- Add a `WishlistProvider` with `addToWishlist(Product)`, `removeFromWishlist(String productID)`, `isWishlisted(String productID)`
- Add a heart icon button on `ProductCard` and `ProductDetailScreen`
- Create a `WishlistScreen` that shows wishlisted products in a grid
- Add the WishlistScreen as a tab or accessible from ProfileScreen

**3. Add Search functionality on HomeScreen:**
- Make the search bar on HomeScreen navigate to ProductListingScreen with the search field auto-focused
- Pass the search query as a parameter

**4. Improve ProductDetailScreen:**
- Add a "Similar Products" horizontal scroll section at the bottom showing products in the same category
- Show a quantity selector (+ / -) before the "Add to Cart" button

**5. Add SharedPreferences persistence:**
- Save logged-in user to SharedPreferences so the app remembers login on restart
- Load user on app startup and skip login screen if already logged in

**6. Add form validation improvements:**
- Show inline error messages on all form fields
- Add email format regex validation

**7. Add Loading / Empty states:**
- Add shimmer loading placeholders for the product grid while "loading" (simulate 1s delay)
- Improve empty state UI for cart and orders screens

**8. Polish UI:**
- Add smooth page transition animations
- Add a floating "scroll to top" button on product listing
- Ensure consistent spacing and typography across all screens

**9. Testing:**
- Write basic widget tests for LoginScreen, CartScreen, and ProductCard

---

### MY FILE STRUCTURE:
```
lib/
├── main.dart
├── theme.dart
├── models/
│   ├── user.dart
│   ├── product.dart
│   ├── cart.dart
│   ├── order.dart
│   └── payment.dart
├── providers/
│   ├── auth_provider.dart
│   ├── product_provider.dart
│   ├── cart_provider.dart
│   └── order_provider.dart
├── screens/
│   ├── login_screen.dart
│   ├── register_screen.dart
│   ├── home_screen.dart
│   ├── product_listing_screen.dart
│   ├── product_detail_screen.dart
│   ├── cart_screen.dart
│   ├── checkout_screen.dart
│   ├── order_success_screen.dart
│   ├── orders_screen.dart
│   └── profile_screen.dart
└── widgets/
    └── product_card.dart
```

---

### SPECIFIC CODE QUESTION (use as needed):

**Q: How do I add SharedPreferences to remember login?**
In `AuthProvider`, inject SharedPreferences and on successful login, save:
```dart
final prefs = await SharedPreferences.getInstance();
await prefs.setString('userID', user.userID);
await prefs.setString('userName', user.name);
await prefs.setString('userEmail', user.email);
```
On app start in `main.dart`, read and auto-login if found.

**Q: How do I add shimmer loading?**
Add `shimmer: ^3.0.0` to pubspec.yaml, then:
```dart
Shimmer.fromColors(
  baseColor: Colors.grey.shade300,
  highlightColor: Colors.grey.shade100,
  child: Container(width: double.infinity, height: 160, color: Colors.white),
)
```

---

### DEMO CREDENTIALS (for testing):
- Email: demo@example.com
- Password: demo123

---

Please help me complete all these tasks one at a time. Start with fixing any issues in the existing code, then implement the Wishlist feature. Show me full Dart code for each file that needs to be created or modified.
