import 'package:flutter/foundation.dart';
import '../models/user.dart';

class AuthProvider extends ChangeNotifier {
  User? _currentUser;
  bool _isLoading = false;

  // Simulated user database
  final List<User> _users = [
    User(
      userID: 'u001',
      name: 'Demo User',
      email: 'demo@example.com',
      password: 'demo123',
    ),
  ];

  User? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;
  bool get isLoading => _isLoading;

  Future<String?> login(String email, String password) async {
    _isLoading = true;
    notifyListeners();

    // Simulate network delay
    await Future.delayed(const Duration(seconds: 1));

    try {
      final user = _users.firstWhere(
        (u) => u.email == email && u.password == password,
        orElse: () => throw Exception('Invalid credentials'),
      );
      _currentUser = user;
      _isLoading = false;
      notifyListeners();
      return null; // null = success
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return 'Invalid email or password';
    }
  }

  Future<String?> register(String name, String email, String password) async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1));

    final exists = _users.any((u) => u.email == email);
    if (exists) {
      _isLoading = false;
      notifyListeners();
      return 'Email already registered';
    }

    final newUser = User(
      userID: 'u${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      email: email,
      password: password,
    );
    _users.add(newUser);
    _currentUser = newUser;
    _isLoading = false;
    notifyListeners();
    return null;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}
