import 'package:flutter/foundation.dart';
import '../models/order.dart';
import '../models/cart.dart';
import '../models/payment.dart';

class OrderProvider extends ChangeNotifier {
  final List<Order> _orders = [];
  final List<Payment> _payments = [];

  List<Order> get orders => List.unmodifiable(_orders);
  List<Order> userOrders(String userID) =>
      _orders.where((o) => o.userID == userID).toList().reversed.toList();

  Future<Order> placeOrder({
    required String userID,
    required List<CartItem> items,
    required double totalAmount,
    required String shippingAddress,
    required PaymentMethod paymentMethod,
  }) async {
    await Future.delayed(const Duration(seconds: 2));

    final order = Order(
      orderID: 'ORD${DateTime.now().millisecondsSinceEpoch}',
      userID: userID,
      items: List.from(items),
      totalAmount: totalAmount,
      shippingAddress: shippingAddress,
      status: OrderStatus.confirmed,
    );

    final payment = Payment(
      paymentID: 'PAY${DateTime.now().millisecondsSinceEpoch}',
      orderID: order.orderID,
      method: paymentMethod,
      status: PaymentStatus.success,
      amount: totalAmount,
    );

    _orders.add(order);
    _payments.add(payment);
    notifyListeners();
    return order;
  }

  Payment? getPaymentForOrder(String orderID) {
    try { return _payments.firstWhere((p) => p.orderID == orderID); } catch (_) { return null; }
  }
}
