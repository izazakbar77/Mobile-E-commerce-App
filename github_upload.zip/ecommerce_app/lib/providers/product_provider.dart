import 'package:flutter/foundation.dart';
import '../models/product.dart';

class ProductProvider extends ChangeNotifier {
  bool _isLoading = false;
  String _searchQuery = '';
  String _selectedCategory = 'All';

  final List<Product> _products = [
    Product(productID: 'p001', name: 'Wireless Headphones', price: 4999, description: 'Premium noise-cancelling wireless headphones with 30h battery life.', imageUrl: 'https://picsum.photos/seed/headphones/400/400', category: 'Electronics', rating: 4.5, stock: 15),
    Product(productID: 'p002', name: 'Running Shoes', price: 3499, description: 'Lightweight breathable running shoes for all terrains.', imageUrl: 'https://picsum.photos/seed/shoes/400/400', category: 'Fashion', rating: 4.2, stock: 20),
    Product(productID: 'p003', name: 'Smart Watch', price: 8999, description: 'Feature-rich smartwatch with health tracking and GPS.', imageUrl: 'https://picsum.photos/seed/watch/400/400', category: 'Electronics', rating: 4.7, stock: 8),
    Product(productID: 'p004', name: 'Cotton T-Shirt', price: 799, description: 'Comfortable 100% cotton t-shirt, available in multiple colors.', imageUrl: 'https://picsum.photos/seed/tshirt/400/400', category: 'Fashion', rating: 4.0, stock: 50),
    Product(productID: 'p005', name: 'Coffee Maker', price: 5499, description: 'Automatic drip coffee maker with programmable timer.', imageUrl: 'https://picsum.photos/seed/coffee/400/400', category: 'Home', rating: 4.3, stock: 12),
    Product(productID: 'p006', name: 'Laptop Backpack', price: 2199, description: 'Waterproof laptop backpack with USB charging port.', imageUrl: 'https://picsum.photos/seed/backpack/400/400', category: 'Fashion', rating: 4.6, stock: 25),
    Product(productID: 'p007', name: 'Bluetooth Speaker', price: 3299, description: '360° surround sound portable speaker, waterproof IPX7.', imageUrl: 'https://picsum.photos/seed/speaker/400/400', category: 'Electronics', rating: 4.4, stock: 18),
    Product(productID: 'p008', name: 'Yoga Mat', price: 1299, description: 'Non-slip eco-friendly yoga and exercise mat.', imageUrl: 'https://picsum.photos/seed/yoga/400/400', category: 'Sports', rating: 4.1, stock: 30),
    Product(productID: 'p009', name: 'Desk Lamp', price: 1599, description: 'LED desk lamp with adjustable brightness and USB port.', imageUrl: 'https://picsum.photos/seed/lamp/400/400', category: 'Home', rating: 4.3, stock: 22),
    Product(productID: 'p010', name: 'Water Bottle', price: 699, description: 'Insulated stainless steel water bottle, keeps cold 24h.', imageUrl: 'https://picsum.photos/seed/bottle/400/400', category: 'Sports', rating: 4.5, stock: 40),
  ];

  List<String> get categories => ['All', ...{..._products.map((p) => p.category)}];
  bool get isLoading => _isLoading;
  String get searchQuery => _searchQuery;
  String get selectedCategory => _selectedCategory;

  List<Product> get filteredProducts {
    return _products.where((p) {
      final matchesSearch = p.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          p.description.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _selectedCategory == 'All' || p.category == _selectedCategory;
      return matchesSearch && matchesCategory;
    }).toList();
  }

  List<Product> get featuredProducts => _products.where((p) => p.rating >= 4.4).toList();

  Product? getById(String id) {
    try { return _products.firstWhere((p) => p.productID == id); } catch (_) { return null; }
  }

  void setSearch(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setCategory(String category) {
    _selectedCategory = category;
    notifyListeners();
  }
}
