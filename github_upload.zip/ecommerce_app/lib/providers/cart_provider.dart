import 'package:flutter/foundation.dart';
import '../models/cart.dart';
import '../models/product.dart';

class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => List.unmodifiable(_items);
  int get itemCount => _items.fold(0, (sum, i) => sum + i.quantity);
  double get totalAmount => _items.fold(0, (sum, i) => sum + i.totalPrice);

  bool contains(String productID) =>
      _items.any((i) => i.product.productID == productID);

  void addItem(Product product) {
    final idx = _items.indexWhere((i) => i.product.productID == product.productID);
    if (idx >= 0) {
      _items[idx].quantity++;
    } else {
      _items.add(CartItem(product: product));
    }
    notifyListeners();
  }

  void removeItem(String productID) {
    _items.removeWhere((i) => i.product.productID == productID);
    notifyListeners();
  }

  void decreaseQuantity(String productID) {
    final idx = _items.indexWhere((i) => i.product.productID == productID);
    if (idx >= 0) {
      if (_items[idx].quantity > 1) {
        _items[idx].quantity--;
      } else {
        _items.removeAt(idx);
      }
      notifyListeners();
    }
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
