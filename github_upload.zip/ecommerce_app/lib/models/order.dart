import 'cart.dart';

enum OrderStatus { pending, confirmed, shipped, delivered, cancelled }

class Order {
  final String orderID;
  final String userID;
  final List<CartItem> items;
  final double totalAmount;
  OrderStatus status;
  final DateTime createdAt;
  final String shippingAddress;

  Order({
    required this.orderID,
    required this.userID,
    required this.items,
    required this.totalAmount,
    this.status = OrderStatus.pending,
    required this.shippingAddress,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  String get statusLabel => status.name[0].toUpperCase() + status.name.substring(1);
}
