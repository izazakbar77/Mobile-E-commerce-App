enum PaymentMethod { creditCard, debitCard, paypal, cashOnDelivery }
enum PaymentStatus { pending, success, failed }

class Payment {
  final String paymentID;
  final String orderID;
  final PaymentMethod method;
  PaymentStatus status;
  final double amount;
  final DateTime processedAt;

  Payment({
    required this.paymentID,
    required this.orderID,
    required this.method,
    this.status = PaymentStatus.pending,
    required this.amount,
    DateTime? processedAt,
  }) : processedAt = processedAt ?? DateTime.now();

  String get methodLabel {
    switch (method) {
      case PaymentMethod.creditCard: return 'Credit Card';
      case PaymentMethod.debitCard: return 'Debit Card';
      case PaymentMethod.paypal: return 'PayPal';
      case PaymentMethod.cashOnDelivery: return 'Cash on Delivery';
    }
  }
}
