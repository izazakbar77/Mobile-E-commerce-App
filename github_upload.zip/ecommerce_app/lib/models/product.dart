class Product {
  final String productID;
  final String name;
  final double price;
  final String description;
  final String imageUrl;
  final String category;
  final double rating;
  int stock;

  Product({
    required this.productID,
    required this.name,
    required this.price,
    required this.description,
    required this.imageUrl,
    required this.category,
    this.rating = 4.0,
    this.stock = 10,
  });

  Map<String, dynamic> toJson() => {
        'productID': productID,
        'name': name,
        'price': price,
        'description': description,
        'imageUrl': imageUrl,
        'category': category,
        'rating': rating,
        'stock': stock,
      };

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        productID: json['productID'],
        name: json['name'],
        price: (json['price'] as num).toDouble(),
        description: json['description'],
        imageUrl: json['imageUrl'],
        category: json['category'],
        rating: (json['rating'] as num? ?? 4.0).toDouble(),
        stock: json['stock'] ?? 10,
      );
}
