class User {
  final String userID;
  final String name;
  final String email;
  String password;

  User({
    required this.userID,
    required this.name,
    required this.email,
    required this.password,
  });

  Map<String, dynamic> toJson() => {
        'userID': userID,
        'name': name,
        'email': email,
        'password': password,
      };

  factory User.fromJson(Map<String, dynamic> json) => User(
        userID: json['userID'],
        name: json['name'],
        email: json['email'],
        password: json['password'],
      );
}
