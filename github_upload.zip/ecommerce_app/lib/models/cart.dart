import 'product.dart';

class CartItem {
  final Product product;
  int quantity;

  CartItem({required this.product, this.quantity = 1});

  double get totalPrice => product.price * quantity;
}

class Cart {
  final String cartID;
  final String userID;
  final List<CartItem> items;

  Cart({required this.cartID, required this.userID, List<CartItem>? items})
      : items = items ?? [];

  double get totalAmount =>
      items.fold(0, (sum, item) => sum + item.totalPrice);

  int get itemCount => items.fold(0, (sum, item) => sum + item.quantity);
}
