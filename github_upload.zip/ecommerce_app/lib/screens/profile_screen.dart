import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/order_provider.dart';
import '../theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;
    final orderCount = context.watch<OrderProvider>().userOrders(user?.userID ?? '').length;

    return Scaffold(
      appBar: AppBar(title: const Text('My Profile'), automaticallyImplyLeading: false),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Avatar & name
          Center(
            child: Column(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: AppTheme.primaryColor,
                  child: Text(user?.name[0].toUpperCase() ?? 'U',
                      style: const TextStyle(fontSize: 32, color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 12),
                Text(user?.name ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
                const SizedBox(height: 4),
                Text(user?.email ?? '', style: const TextStyle(color: AppTheme.textSecondary)),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Stats
          Row(
            children: [
              Expanded(child: _StatCard(label: 'Orders', value: '$orderCount', icon: Icons.receipt_long_rounded)),
              const SizedBox(width: 12),
              const Expanded(child: _StatCard(label: 'Wishlist', value: '0', icon: Icons.favorite_rounded)),
            ],
          ),
          const SizedBox(height: 24),

          // Menu items
          _MenuItem(icon: Icons.person_outline, title: 'Edit Profile', onTap: () {}),
          _MenuItem(icon: Icons.location_on_outlined, title: 'Shipping Addresses', onTap: () {}),
          _MenuItem(icon: Icons.payment_outlined, title: 'Payment Methods', onTap: () {}),
          _MenuItem(icon: Icons.notifications_outlined, title: 'Notifications', onTap: () {}),
          _MenuItem(icon: Icons.help_outline, title: 'Help & Support', onTap: () {}),
          _MenuItem(icon: Icons.info_outlined, title: 'About App', onTap: () {
            showAboutDialog(
              context: context,
              applicationName: 'ShopApp',
              applicationVersion: '1.0.0',
              applicationLegalese: 'MAD Semester Project\nMuhammad Murtaza (23MDBCS443)\nIzaz Akbar (23MDBCS436)',
            );
          }),
          const Divider(height: 32),
          _MenuItem(
            icon: Icons.logout,
            title: 'Sign Out',
            color: Colors.red,
            onTap: () {
              context.read<AuthProvider>().logout();
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
            },
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const _StatCard({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.primaryColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(icon, color: AppTheme.primaryColor),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
          Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
        ],
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Color? color;
  const _MenuItem({required this.icon, required this.title, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color ?? AppTheme.primaryColor),
      title: Text(title, style: TextStyle(color: color ?? AppTheme.textPrimary, fontWeight: FontWeight.w500)),
      trailing: color == null ? const Icon(Icons.chevron_right, color: Colors.grey) : null,
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}
