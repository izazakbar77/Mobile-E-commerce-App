import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/cart_provider.dart';
import '../theme.dart';
import 'cart_screen.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  bool _added = false;

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final inCart = cart.contains(widget.product.productID);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Image App Bar
          SliverAppBar(
            expandedHeight: 320,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                widget.product.imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: Colors.grey.shade200,
                  child: const Icon(Icons.image, size: 80, color: Colors.grey),
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.shopping_cart_outlined, color: Colors.white),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
              ),
            ],
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Category badge
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(widget.product.category,
                        style: const TextStyle(color: AppTheme.primaryColor, fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(height: 12),

                  // Name
                  Text(widget.product.name,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
                  const SizedBox(height: 8),

                  // Rating & stock
                  Row(
                    children: [
                      ...List.generate(5, (i) => Icon(
                        i < widget.product.rating.round() ? Icons.star_rounded : Icons.star_outline_rounded,
                        color: Colors.amber, size: 20,
                      )),
                      const SizedBox(width: 8),
                      Text(widget.product.rating.toString(),
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Icon(Icons.inventory_2_outlined, size: 16, color: widget.product.stock > 0 ? Colors.green : Colors.red),
                      const SizedBox(width: 4),
                      Text('${widget.product.stock} in stock',
                          style: TextStyle(color: widget.product.stock > 0 ? Colors.green : Colors.red, fontSize: 13)),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Price
                  Text('Rs. ${widget.product.price.toStringAsFixed(0)}',
                      style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppTheme.primaryColor)),
                  const SizedBox(height: 20),

                  // Description
                  const Text('Description', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textPrimary)),
                  const SizedBox(height: 8),
                  Text(widget.product.description,
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 15, height: 1.6)),
                  const SizedBox(height: 32),

                  // Add to cart
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: Icon(inCart ? Icons.check : Icons.shopping_cart_outlined),
                      label: Text(inCart ? 'Added to Cart' : 'Add to Cart'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: inCart ? Colors.green : AppTheme.primaryColor,
                      ),
                      onPressed: widget.product.stock == 0
                          ? null
                          : () {
                              context.read<CartProvider>().addItem(widget.product);
                              setState(() => _added = true);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('${widget.product.name} added to cart!'),
                                  behavior: SnackBarBehavior.floating,
                                  action: SnackBarAction(
                                    label: 'View Cart',
                                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
                                  ),
                                ),
                              );
                            },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
